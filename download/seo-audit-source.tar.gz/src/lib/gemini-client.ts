// ============================================================
// Gemini-клиент через OpenAI-compatible endpoint.
// Gemini поддерживает совместимый с OpenAI API на /v1beta/openai/
// Используем plain fetch — без SDK, чтобы не тянуть зависимости.
// ============================================================

const GEMINI_API_KEY = process.env.GEMINI_API_KEY || 'AQ.Ab8RN6IxDQhWygluroDRp0W9TvYIgnNO4cg4jWiWZRd_qhg18w';
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-3.1-flash-lite';
const GEMINI_BASE_URL = process.env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com/v1beta/openai';

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface ChatCompletionResult {
  content: string;
}

/**
 * Создаёт chat completion через Gemini OpenAI-compatible endpoint.
 * Сигнатура максимально близка к z-ai-web-dev-sdk, чтобы легко заменить.
 */
export async function createChatCompletion(
  messages: ChatMessage[],
  options: { timeoutMs?: number } = {},
): Promise<ChatCompletionResult> {
  const timeoutMs = options.timeoutMs || 60000;

  // Gemini OpenAI-compatible: системный промпт должен быть role: 'system'
  // (но некоторые модели хотят 'user' — отправляем как есть)
  const res = await fetch(`${GEMINI_BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${GEMINI_API_KEY}`,
    },
    body: JSON.stringify({
      model: GEMINI_MODEL,
      messages,
      temperature: 0.7,
      max_tokens: 2000,
    }),
    signal: AbortSignal.timeout(timeoutMs),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    throw new Error(`Gemini API ${res.status}: ${errText.slice(0, 500)}`);
  }

  const data = (await res.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
    error?: { message?: string };
  };

  if (data.error) {
    throw new Error(`Gemini error: ${data.error.message || 'unknown'}`);
  }

  const content = data.choices?.[0]?.message?.content || '';
  if (!content) {
    throw new Error('Gemini: пустой ответ');
  }

  return { content };
}
