#!/bin/bash
# ============================================================
# Deploy script для Plesk — выполняется после git pull
# Устанавливает зависимости, собирает проект, перезапускает Node.js
# ============================================================

set -e

echo "=========================================="
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting Plesk deployment"
echo "=========================================="

# Переходим в директорию проекта
cd "$(dirname "$0")"

# Устанавливаем зависимости
echo "[1/4] Installing dependencies..."
npm install --legacy-peer-deps --production=false
echo "Dependencies installed."

# Собираем проект
echo "[2/4] Building Next.js..."
npm run build
echo "Build complete."

# Копируем public в standalone (для output: standalone)
echo "[3/4] Copying static files..."
if [ -d ".next/standalone" ]; then
  cp -r public .next/standalone/ 2>/dev/null || true
  cp -r .next/static .next/standalone/.next/ 2>/dev/null || true
  echo "Static files copied."
else
  echo "Warning: .next/standalone not found — using standard next start"
fi

# Перезапускаем приложение
echo "[4/4] Restarting application..."
if command -v pm2 &> /dev/null; then
  # Через PM2 (если установлен)
  pm2 restart seo-audit --update-env 2>/dev/null || pm2 start "npm run start" --name seo-audit
  pm2 save
  echo "Application restarted via PM2."
elif command -v passenger &> /dev/null; then
  # Через Phusion Passenger (Plesk Node.js)
  touch tmp/restart.txt 2>/dev/null || true
  echo "Application restart signal sent to Passenger."
else
  # Fallback — просто запускаем
  echo "Warning: PM2/Passenger not found. Start manually: npm run start"
fi

echo "=========================================="
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Deployment complete!"
echo "=========================================="
